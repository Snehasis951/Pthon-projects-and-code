import smtplib as sm

ob =sm.SMTP('smtp.gmail.com',587)
ob.ehlo()
ob.starttls()
ob.login('snehasismondal26132@gmail.com','Snemond27@')
subject="multiple mail through python"
body="testing purpose"
message="subject:{}\n\n{}".format(subject,body)
listadd=['snehasismondal210@gmail.com','marvelavengers24680@gmail.com','snehasismondl26132@gmail.com']
ob.sendmail('snehasismondal26132@gmail.com',listadd,message)
print("mails have been sent")
ob.quit()