import re #regex module

email_valid = "^[a-z]+[\._]?[a-z 0-9]+[@]\w+[.]\w{2,3}$"
# ^	       Starts with
# \	       Signals a special sequence
# ?	       Zero or one occurrences
# \w	   Returns a match where the string contains any word characters 
# $	       Ends with
user_email=input("Entern your mail: ")

if re.search(email_valid, user_email):
    print("Right email")
else:
    print("Wrong email")
