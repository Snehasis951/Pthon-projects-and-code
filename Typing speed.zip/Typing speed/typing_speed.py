from time import *
import random as r

def mistake(partest, usertest):
    error =0
    for i in range(len(partest)):
        try:
            if partest[i] != usertest[i]:
                error = error + 1
        # except Exception as e:
            # raise e
        except :
            error = error + 1

    return error

def speed_time(time_start, time_end, userinput):
    time_delay = time_end - time_start
    time_round = round(time_delay, 2)
    speed = len(userinput)/time_round
    return round(speed) 


test=["Strings are used", "for storing text/characters", "For example Hello World", "is a string of characters."]
test1 = r.choice(test)
print(" ****** Typing speed calculator ****** ")
print(test1)
print()
print()
time_1 = time()
test_input = input("Enter: ")
time_2 = time()

print("Speed: ", speed_time(time_1, time_2, test_input), "w/sec")
print("Error: ", mistake(test1, test_input))