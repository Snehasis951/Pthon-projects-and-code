from plyer import notification
from bs4 import BeautifulSoup
import requests
import time


def notifyME(title, message):
    notification.notify(
        title = title,
        message = message,
        app_icon = "D:\Python\python_playlist\coronavirus 2\covidNotify\icon.ico",
        timeout = 10
    )


def getData(url):
    req = requests.get(url)
    return req.text



if __name__ == "__main__":
    # while True:
        # notifyME("SNEHASIS", "Lets stop the spread of this virus together")
        myData = getData('https://www.mohfw.gov.in/')
        # print(myData)
        soup = BeautifulSoup(myData, 'html.parser')
        # print(soup.prettify())
        myStrData = ""
        for tr in soup.find_all('tbody')[1].find_all('tr'):
            myStrData += tr.get_text()
            # print(myStrData.split("\n"))
        myStrData = myStrData[1:]
        itemList = myStrData.split("\n\n")

        states = ['Chandigarh', 'Telengana', 'Uttar Pradesh']
        for item in itemList[0:22]:
            dataList = item.split('\n')
            if dataList[1] in states: 
                n_Title = 'Cases of Covid-19'
                n_Text = f"State {dataList[1]}\nIndian : {dataList[2]} & Foreign : {dataList[3]}\nCured :  {dataList[4]}\nDeaths :  {dataList[5]}"
                notifyME(n_Title, n_Text)
                time.sleep(2)
        time.sleep(3600)


