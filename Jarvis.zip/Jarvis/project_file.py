import pyttsx3 #pip install pyttsx3
import speech_recognition as sr #pip install speechRecognition
import datetime
import wikipedia #pip install wikipedia
import webbrowser
import os
import smtplib

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
# print(voices[0],id)
engine.setProperty('voice', voices[0].id)



def speak(audio):
    engine.say(audio)
    engine.runAndWait()

def wish_Me():
    hour = int(datetime.datetime.now().hour)
    if hour >= 0 and hour < 12:
        speak("Good Morning, Master")
    elif hour >= 12 and hour < 18:
        speak("Good Afternoon, Master")
    else:
        speak("Good Evening, Master")

    speak("I am Ultron")

def take_Command():

    r =sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening.....")
        r.pause_threshold = 1
        audio = r.listen(source)
    try:
        print("Recognizing.....")
        query = r.recognize_google(audio, language='en-in')
        print(f"User said: {query}")
    except Exception as e:
        # print(e)
        print("Please say that again")
        return "None"
    return query

def sendEmail(to, content):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()
    server.login('snehasismondl26132@gmail.com', 'Snehasis112233@')
    server.sendmail('snehasismondl26132@gmail.com', to, content)
    server.close()


if __name__ == "__main__":
    # speak("The world is under pandemic situation")
    wish_Me()
    # take_Command()
    while True:
        query = take_Command().lower()

        if 'wikipedia' in query:
            speak("Searching Wikipedia....")
            query = query.replace("wikipedia", " ")
            results = wikipedia.summary(query, sentences = 3)
            speak("According to Wikipedia..")
            print(results)
            speak(results)
        elif 'open youtube' in query:
            webbrowser.open("youtube.com")
        elif 'open google' in query:
            webbrowser.open("google.com")
        elif 'open stackoverflow' in query:
            webbrowser.open("stackoverflow.com") 

        elif 'play music' in query:
            music_dir = 'D:\\music\\songs'
            songs = os.listdir(music_dir)
            print(songs)
            os.startfile(os.path.join(music_dir, songs[0]))

        elif 'what is the time' in query:
            time_now = datetime.datetime.now().strftime("%H:%M:%S")
            speak(f"the time is {time_now}")
        elif 'open code' in query:
            code_path = "C:\\Users\\snehasis mondal\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe"
        elif 'send email' in query:
            try: 
                speak("what should I send?")
                content = take_Command()
                to = "mondalsuranjana490@gmail.com"
                sendEmail(to, content)
                speak("Email has been sent")
            except Exception as e:
                print(e)
                speak("Sorry, I am not able to send the mail")