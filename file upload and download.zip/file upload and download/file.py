from ftpretty import ftpretty

def upload(filename,
           user= 'xxxxxx',
           password='xxxxxxxxxxx',
           host='xx.xx.xx.xx'):
    f = ftpretty(host,user,password)
    only_file_name = filename.split('/')[-1] 
    f.put(filename,'/my_uploads/'+only_file_name) 
def download(
           user= 'xxxxxx',
           password='xxxxxxxxxxx',
           host='xx.xx.xx.xx'):
    f = ftpretty(host,user,password)
    f.get("D:\necessary documents\necessary documents\necessary documents\sign.jpeg")   
    print("File downloaded")

if __name__ =="__main__":
    upload(filename='file.py')