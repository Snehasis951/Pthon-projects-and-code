from instabot import Bot

bot = Bot()
bot.login(username="vividsnaps123", password="Viv123snaps@")
# bot.follow("instagram")
# bot.upload_photo("D:\Python projects\QR code generator\CodeWithHarry_youtube.png")
# bot.unfollow("instagram")
# bot.set_message("snehasis", ["instgram", "snehasis.mondal_007"])
# followers = bot.get_user_followers("vividsnaps123")
# for follower in followers:
    # print(bot.get_user_info(follower))
followerings = bot.get_user_following("vividsnaps123")
for following in followerings:
    print(bot.get_user_info(following))