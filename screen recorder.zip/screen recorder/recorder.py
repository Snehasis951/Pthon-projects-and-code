import cv2
import numpy as np
import pyautogui
import time
import win32gui
import win32con
from os import mkdir



try:
    mkdir("recordings")
except FileExistsError:
    pass


def minimizeWindow():
    window = win32gui.FindWindow(None,"Screen recorder")
    win32gui.ShowWindow(window,win32con.SW_MINIMIZE)


SCREEN_SIZE = (1366, 768)

fourcc = cv2.VideoWriter_fourcc(*"XVID")

output = cv2.VideoWriter("recordings/"+"SreenRecording "+time.strftime("%H-%M-%S %d-%m-%y")+".mp4",fourcc, 20.0, (SCREEN_SIZE))
print("Recording started.... \nwindow minimized in taskbar.\npress q to exit.")

minimized = False
while True:

    img = pyautogui.screenshot()

    frame = np.array(img)

    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    cv2.imshow("Screen recorder", frame)
    if minimized== True:
        pass
    else:
        minimized = True
        minimizeWindow()
        
    output.write(frame)

    if cv2.waitKey(1) == ord("q"):
        print("\rRecording Finished.")
        break

output.release()
cv2.destroyAllWindows()